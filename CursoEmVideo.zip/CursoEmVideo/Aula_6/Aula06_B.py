n = input('Digite algo: ')
print(n.isnumeric()) # n.isnumeri significa (n é um número?). Ele irá pegar o valor inserido e ver se é possível converter para numérico.
print(n.isalpha()) # "Ele é alfabético? Se no valor tiver apenas letras, então sairá TRUE
print(n.isalnum()) # "Se o valor inserido possui letras e números sairá TRUE.
print(n.isupper()) # Se o valor possui apenas letras maiúsculas.
print(n.islower()) # Se o valor possui apenas letras minúsculas.
