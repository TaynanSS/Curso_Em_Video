a = int(input('Digite algo: '))
print(type(a))