n1 = int(input('Digite um número: '))
n2 = int(input('Digite outro: '))
soma = n1 + n2
print('A soma de {} e {} é igual a {}'.format(n1, n2, soma))
