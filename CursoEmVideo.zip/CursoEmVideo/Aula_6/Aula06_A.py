n1 = int(input('Digite um valor: '))
n2 = int(input('Digite outro: '))
soma = n1+n2
# print('A soma entre', n1, 'e', n2, 'é igual a', soma)
print('A soma entre {} e {} é igual a {}'.format(n1,n2,soma))
# print('A soma entre {0} e {1} é igual a {2}'.format(n1,n2,soma))

