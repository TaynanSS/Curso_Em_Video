frase = 'Curso em Video Python'
print('-'.join(frase.split()))
