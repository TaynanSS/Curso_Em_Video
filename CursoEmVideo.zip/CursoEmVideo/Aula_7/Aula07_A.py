# + adição
# - subtração
# * multiplicação
# / divisão
# ** potência
# // divisão inteira
# % resto da divisão
# Ordem de Precedência --> 1° () --> 2° ** potência --> 3° *, /, //, % --> 4° +, -