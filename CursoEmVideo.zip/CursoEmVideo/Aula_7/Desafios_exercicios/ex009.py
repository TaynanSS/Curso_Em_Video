# Faça um programa que leia um número Inteiro qualquer e mostre na tela a sua tabuada.

valor = int(input('Digite um número inteiro: '))
tab1 = valor * 1
tab2 = valor * 2
tab3 = valor * 3
tab4 = valor * 4
tab5 = valor * 5
tab6 = valor * 6
tab7 = valor * 7
tab8 = valor * 8
tab9 = valor * 9
print('Tabuada do valor digitado: \n {}x1= {}\n'
      '{}x2= {}\n'
      '{}x3= {}\n'
      '{}x4= {}\n'
      '{}x5= {}\n'
      '{}x6= {}\n'
      '{}x7= {}\n'
      '{}x8= {}\n'
      '{}x9= {}\n'.format(valor, tab1, valor, tab2, valor, tab3,valor, tab4,valor, tab5,valor, tab6,valor, tab7,valor, tab8, valor, tab9))


