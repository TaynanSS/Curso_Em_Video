nome = input('Digite seu nome: ')
print('Prazer, {}!'.format(nome))

