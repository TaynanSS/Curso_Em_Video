n1 = float(input('Digite um número: '))
n2 = float(input('Digite outro número: '))
soma = n1 + n2
print('A soma entre {} e {} é igual a {}'.format(n1, n2, soma))
